export var Add = (x, y) => x + y;
