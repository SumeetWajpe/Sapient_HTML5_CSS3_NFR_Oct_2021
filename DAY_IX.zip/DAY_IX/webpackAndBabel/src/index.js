import { Add } from "./math";
export let x = 10;

export class Point {
  constructor() {
    this.x = 10;
    this.y = 20;
  }
}

var pointObj = new Point();
console.log(`The point is : [X:${pointObj.x},Y:${pointObj.y}]`);

console.log("The addition is : " + Add(20, 30));
