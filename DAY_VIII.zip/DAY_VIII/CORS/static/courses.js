// console.log("Courses.js loaded !");

function FetchCourses() {
  fetch("http://localhost:5000/courses")
    .then((res) => {
      if (res.ok) {
        return res.json();
      } else {
        throw new Error("Something went wrong !");
      }
    })
    .then((courses) => console.log(courses));
}
FetchCourses();
