// import Multiply, { Add as Addition, Subtract } from "./Math.js";
// console.log("Addition is : " + Addition(20, 40));
// console.log("The Product  is : " + Multiply(20, 40));

import * as MathModule from "./Math.js";

console.log(MathModule.Add(40, 30));
