const express = require("express");
const app = express();
const path = require("path");
var courses = require("./models/course.model");

app.use(express.static(path.join(__dirname, "static")));
app.use(express.json());
// app.get("/", (req, res) => res.send("Hello Express !"));
app.get("/", (req, res) => res.sendFile("Courses.html", { root: __dirname }));

app.get("/courses", (req, res) => {
  // comes form db
  res.json(courses);
});

app.delete("/course/:id", (req, res) => {
  let courseId = +req.params.id;
  // immutablity(functional prog) -> filter

  let index = courses.findIndex((c) => c.id === courseId);
  courses.splice(index, 1);
  res.json({ msg: "success" });
});

app.post("/newcourse", (req, res) => {
  // get the data from client (req)
  let newCourseToBeAdded = req.body;
  // immutability (functional prog)
  // courses = [...courses, newCourseToBeAdded];

  // object oriented
  courses.push(newCourseToBeAdded);
  res.json({ msg: "success" });
});

// app.get("/courses.js", (req, res) =>
//   res.sendFile("courses.js", { root: __dirname })
// );

app.listen(5000, () => console.log("Server running @ 5000"));
