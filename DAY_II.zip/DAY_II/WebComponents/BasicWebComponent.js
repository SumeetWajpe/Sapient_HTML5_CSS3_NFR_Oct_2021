class BasicComponent extends HTMLElement {
  constructor() {
    super();
    console.log("Hello Web Component !");
  }
}

// register
customElements.define("uc-basic-component", BasicComponent);
