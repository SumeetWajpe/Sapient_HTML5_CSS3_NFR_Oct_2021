// No access to document | window
// No access to global variables from (.html) main thread !
// access to XMLHttpRequest -> AJAX | fetch
// No access to localStorage | sessionStorage, but access to IndexedDB
// document.write("Hello !");
onmessage = function (msgFromMainThread) {
  var largeArray = [];

  console.log(msgFromMainThread.data);
  //   postMessage("Msg from Worker Thread !");
  for (let i = 0; i < 7000; i++) {
    largeArray[i] = [];
    for (let j = 0; j < 7000; j++) {
      largeArray[i][j] = Math.random();
    }
  }
  postMessage(largeArray[3000][3000]);
};
