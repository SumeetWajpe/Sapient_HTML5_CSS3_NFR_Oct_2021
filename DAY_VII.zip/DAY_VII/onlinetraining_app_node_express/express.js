const express = require("express");
const app = express();

// app.get("/", (req, res) => res.send("Hello Express !"));
app.get("/", (req, res) => res.sendFile("Index.html", { root: __dirname }));

app.get("/courses", (req, res) => {
  // comes form db
  var courses = [
    { id: 1, title: "React", price: 5000 },
    { id: 2, title: "Redux", price: 6000 },
  ];
  res.json(courses);
});

app.listen(5000, () => console.log("Server running @ 5000"));
