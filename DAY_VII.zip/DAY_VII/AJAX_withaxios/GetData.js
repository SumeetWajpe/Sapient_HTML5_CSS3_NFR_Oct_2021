function GetPostData() {
  return axios.get("https://jsonplaceholder.typicode.com/posts");
}
