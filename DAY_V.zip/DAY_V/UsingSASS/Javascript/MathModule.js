var MathModule = { PI: 3.14 };

var MathModule = (function (MathModule) {
  MathModule.Add = function (x, y) {
    return x + y;
  };

  function Product(x, y) {
    return x * y;
  }
  return MathModule;
})(MathModule || {});

// var MathModule = (function () {
//   var PI = 3.14;
//   function Add(x, y) {
//     return x + y;
//   }

//   function Product(x, y) {
//     return x * y;
//   }

//   return {
//     Add: Add,
//     // PI: PI,
//     // Multiplication:Product
//   };
// })();
